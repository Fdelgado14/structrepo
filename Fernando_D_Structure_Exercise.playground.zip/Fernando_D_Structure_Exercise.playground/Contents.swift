import UIKit

struct Engine {
    var length = 175.6
    var width = 64.8
}
